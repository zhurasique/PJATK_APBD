﻿namespace PjatkAcademy
{
    partial class KandydaciForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.kandydaciDataGridView = new System.Windows.Forms.DataGridView();
            this.KandydaciBox = new System.Windows.Forms.GroupBox();
            this.DodajButton = new System.Windows.Forms.Button();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.dodajToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.kandydaciDataGridView)).BeginInit();
            this.KandydaciBox.SuspendLayout();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // kandydaciDataGridView
            // 
            this.kandydaciDataGridView.AllowUserToAddRows = false;
            this.kandydaciDataGridView.AllowUserToDeleteRows = false;
            this.kandydaciDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.kandydaciDataGridView.ContextMenuStrip = this.contextMenuStrip1;
            this.kandydaciDataGridView.Location = new System.Drawing.Point(12, 12);
            this.kandydaciDataGridView.Name = "kandydaciDataGridView";
            this.kandydaciDataGridView.ReadOnly = true;
            this.kandydaciDataGridView.Size = new System.Drawing.Size(467, 252);
            this.kandydaciDataGridView.TabIndex = 0;
            // 
            // KandydaciBox
            // 
            this.KandydaciBox.Controls.Add(this.DodajButton);
            this.KandydaciBox.Location = new System.Drawing.Point(12, 270);
            this.KandydaciBox.Name = "KandydaciBox";
            this.KandydaciBox.Size = new System.Drawing.Size(467, 46);
            this.KandydaciBox.TabIndex = 1;
            this.KandydaciBox.TabStop = false;
            // 
            // DodajButton
            // 
            this.DodajButton.Location = new System.Drawing.Point(3, 16);
            this.DodajButton.Name = "DodajButton";
            this.DodajButton.Size = new System.Drawing.Size(75, 23);
            this.DodajButton.TabIndex = 0;
            this.DodajButton.Text = "Dodaj";
            this.DodajButton.UseVisualStyleBackColor = true;
            this.DodajButton.Click += new System.EventHandler(this.DodajButton_Click);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dodajToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(106, 26);
            // 
            // dodajToolStripMenuItem
            // 
            this.dodajToolStripMenuItem.Name = "dodajToolStripMenuItem";
            this.dodajToolStripMenuItem.Size = new System.Drawing.Size(105, 22);
            this.dodajToolStripMenuItem.Text = "Dodaj";
            this.dodajToolStripMenuItem.Click += new System.EventHandler(this.DodajButton_Click);
            // 
            // KandydaciForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(491, 320);
            this.Controls.Add(this.KandydaciBox);
            this.Controls.Add(this.kandydaciDataGridView);
            this.Name = "KandydaciForm";
            this.Text = "Kandydaci";
            ((System.ComponentModel.ISupportInitialize)(this.kandydaciDataGridView)).EndInit();
            this.KandydaciBox.ResumeLayout(false);
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView kandydaciDataGridView;
        private System.Windows.Forms.GroupBox KandydaciBox;
        private System.Windows.Forms.Button DodajButton;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem dodajToolStripMenuItem;
    }
}

