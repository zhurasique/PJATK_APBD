﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PjatkAcademy
{
    public class Kandydat
    {
        public string Imie { get; set; }
        public string Nazwisko { get; set; }
        public string Pesel { get; set; }
        public string Telefon { get; set; }
        public string Email { get; set; }
        public DateTime DataUrodzenia { get; set; }
    }
}
