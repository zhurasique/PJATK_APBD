﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PjatkAcademy
{
    public partial class DodajKandydataForm : Form
    {
        public DodajKandydataForm()
        {
            InitializeComponent();
        }
        public Kandydat GetKandydat { get; set; }

   

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Kandydat kandydat = new Kandydat
            {
                Imie = textBoxImie.Text,
                DataUrodzenia = dateTimePickerDU.Value.Date,
                Nazwisko = textBoxNazwisko.Text,
                Pesel = textBoxPESEL.Text,
                Email = textBoxEmail.Text,
                Telefon = textBoxTelefon.Text
            };

            GetKandydat = kandydat;

            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void dateTimePickerDU_ValueChanged(object sender, EventArgs e)
        {

        }

        private void buttonAnuluj_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }
    }
}
