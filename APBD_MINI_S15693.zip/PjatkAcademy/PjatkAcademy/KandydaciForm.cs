﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PjatkAcademy
{
    public partial class KandydaciForm : Form
    {
        private List<Kandydat> listaKandydatow = new List<Kandydat>()
        {
            new Kandydat {Imie = "Jan", Nazwisko = "Nowak", Pesel = "12646213212", DataUrodzenia = new DateTime(1990, 10, 23 ), Email = "sss@gmail.x", Telefon = "21-21-12" },
            new Kandydat {Imie = "Jan", Nazwisko = "Nowak", Pesel = "12646213212", DataUrodzenia = new DateTime(1990, 10, 23 ), Email = "sssaf21s@gmail.x", Telefon = "21-121-12" } 
        };
        public KandydaciForm()
        {
            InitializeComponent();
            LoadData();
        }

        public void LoadData()
        {
            BindingSource bs = new BindingSource();
            bs.DataSource = listaKandydatow;
            kandydaciDataGridView.DataSource = bs;
        }

        private void DodajButton_Click(object sender, EventArgs e)
        {
            DodajKandydataForm form = new DodajKandydataForm();
            form.ShowDialog();
            if(form.DialogResult == DialogResult.OK)
            {
                listaKandydatow.Add(form.GetKandydat);
                LoadData();
            }
        }
    }
}
